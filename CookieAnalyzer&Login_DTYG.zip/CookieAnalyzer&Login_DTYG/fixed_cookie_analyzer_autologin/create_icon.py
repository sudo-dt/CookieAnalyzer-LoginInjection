#!/usr/bin/env python3
"""
Create a simple icon for the Cookie Analyzer application
"""

from PIL import Image, ImageDraw

def create_icon():
    # Create a 256x256 image with a blue background
    img = Image.new('RGB', (256, 256), color=(53, 92, 125))
    draw = ImageDraw.Draw(img)
    
    # Draw a cookie shape
    # Outer circle (cookie)
    draw.ellipse((28, 28, 228, 228), fill=(205, 170, 125))
    
    # Cookie chips
    chips = [
        (80, 70, 110, 100),
        (150, 60, 180, 90),
        (70, 150, 100, 180),
        (140, 140, 170, 170),
        (110, 110, 140, 140)
    ]
    
    for chip in chips:
        draw.ellipse(chip, fill=(90, 60, 40))
    
    # Add a bite
    draw.ellipse((170, 20, 270, 120), fill=(53, 92, 125))
    
    # Save as PNG and ICO
    img.save('icon.png')
    img.save('icon.ico')
    
    print("Icon created successfully!")

if __name__ == "__main__":
    try:
        create_icon()
    except Exception as e:
        print(f"Error creating icon: {e}")
        print("Please install Pillow with: pip install pillow")