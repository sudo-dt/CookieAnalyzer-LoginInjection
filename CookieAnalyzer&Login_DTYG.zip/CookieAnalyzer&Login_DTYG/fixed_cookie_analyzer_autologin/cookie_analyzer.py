#!/usr/bin/env python3
"""
Cookie Analyzer Tool

This tool analyzes browser cookie files to determine:
- Which domains the cookies belong to
- Which cookies are likely authentication/login cookies
- What potential privileges these cookies might grant
- Security and privacy implications

Supports Netscape cookie format and JSON exports.
"""

import os
import re
import json
import argparse
import datetime
from urllib.parse import urlparse
from collections import defaultdict

# Known authentication cookie names (common patterns)
AUTH_COOKIE_PATTERNS = [
    r'auth', r'login', r'sess', r'sid', r'token', r'jwt', r'access', 
    r'account', r'user', r'uid', r'remember', r'sign', r'logged', r'secure',
    r'credential', r'persistent', r'stay', r'id_token', r'oauth'
]

# High-value domains (financial, email, social media, etc.)
HIGH_VALUE_DOMAINS = {
    'banking': [
        'chase.com', 'bankofamerica.com', 'wellsfargo.com', 'citibank.com', 
        'capitalone.com', 'paypal.com', 'venmo.com', 'wise.com'
    ],
    'email': [
        'gmail.com', 'outlook.com', 'yahoo.com', 'protonmail.com', 'mail.com',
        'aol.com', 'icloud.com', 'zoho.com'
    ],
    'social_media': [
        'facebook.com', 'twitter.com', 'instagram.com', 'tiktok.com',
        'linkedin.com', 'reddit.com', 'pinterest.com', 'snapchat.com'
    ],
    'shopping': [
        'amazon.com', 'ebay.com', 'walmart.com', 'target.com', 'aliexpress.com',
        'etsy.com', 'bestbuy.com', 'shopify.com'
    ],
    'cloud_storage': [
        'drive.google.com', 'dropbox.com', 'onedrive.com', 'box.com',
        'icloud.com', 'mega.nz'
    ]
}

# Tracking/advertising domains
TRACKING_DOMAINS = [
    'doubleclick.net', 'google-analytics.com', 'facebook.net', 'criteo.com',
    'adnxs.com', 'rubiconproject.com', 'pubmatic.com', 'casalemedia.com',
    'advertising.com', 'smartadserver.com', 'smaato.net', 'media.net'
]

class CookieAnalyzer:
    def __init__(self):
        self.cookies = []
        self.domains = set()
        self.auth_cookies = []
        self.domain_categories = defaultdict(list)
        self.high_risk_cookies = []
        self.tracking_cookies = []
        
    def load_netscape_format(self, file_path):
        """Load cookies from a Netscape format cookie file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            parts = line.split('\t')
                            if len(parts) >= 7:
                                cookie = {
                                    "domain": parts[0],
                                    "include_subdomains": parts[1].lower() == "true",
                                    "path": parts[2],
                                    "secure": parts[3].lower() == "true",
                                    "expires": int(parts[4]),
                                    "name": parts[5],
                                    "value": parts[6]
                                }
                                self.cookies.append(cookie)
                                self.domains.add(cookie["domain"])
                        except Exception as e:
                            print(f"Error parsing line: {line}")
                            print(f"Error details: {e}")
            return True
        except Exception as e:
            print(f"Error loading cookie file: {e}")
            return False
            
    def load_json_format(self, file_path):
        """Load cookies from a JSON format cookie file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # Handle different JSON formats
            if isinstance(data, list):
                for cookie in data:
                    if isinstance(cookie, dict) and "domain" in cookie and "name" in cookie:
                        self.cookies.append(cookie)
                        self.domains.add(cookie["domain"])
            elif isinstance(data, dict) and "cookies" in data:
                for cookie in data["cookies"]:
                    if isinstance(cookie, dict) and "domain" in cookie and "name" in cookie:
                        self.cookies.append(cookie)
                        self.domains.add(cookie["domain"])
                        
            return True
        except Exception as e:
            print(f"Error loading JSON cookie file: {e}")
            return False
    
    def detect_file_format(self, file_path):
        """Detect the format of the cookie file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
                
            if first_line.startswith('{') or first_line.startswith('['):
                return "json"
            elif '\t' in first_line:
                return "netscape"
            else:
                # Try to determine based on file extension
                if file_path.lower().endswith('.json'):
                    return "json"
                elif file_path.lower().endswith('.txt'):
                    return "netscape"
                else:
                    return "unknown"
        except Exception:
            return "unknown"
    
    def load_cookies(self, file_path):
        """Load cookies from file, detecting format automatically."""
        format_type = self.detect_file_format(file_path)
        
        if format_type == "netscape":
            return self.load_netscape_format(file_path)
        elif format_type == "json":
            return self.load_json_format(file_path)
        else:
            print(f"Unknown cookie file format. Please provide a Netscape format or JSON cookie file.")
            return False
    
    def identify_auth_cookies(self):
        """Identify cookies that are likely used for authentication."""
        for cookie in self.cookies:
            # Check if cookie name matches authentication patterns
            if any(re.search(pattern, cookie["name"].lower()) for pattern in AUTH_COOKIE_PATTERNS):
                self.auth_cookies.append(cookie)
                continue
                
            # Check for long, complex values (potential tokens)
            if len(cookie["value"]) > 30 and re.search(r'[A-Za-z0-9+/=_-]{30,}', cookie["value"]):
                self.auth_cookies.append(cookie)
                continue
                
            # Check for secure, httpOnly cookies with paths
            if cookie.get("secure", False) and cookie.get("path", "") == "/":
                if len(cookie["value"]) > 10:  # Avoid short values
                    self.auth_cookies.append(cookie)
    
    def categorize_domains(self):
        """Categorize domains by type (banking, social media, etc.)."""
        for cookie in self.cookies:
            domain = cookie["domain"].lstrip('.')
            
            # Check if it's a tracking domain
            if any(tracker in domain for tracker in TRACKING_DOMAINS):
                self.tracking_cookies.append(cookie)
                self.domain_categories["tracking"].append(domain)
                continue
                
            # Check high-value domains
            for category, domains in HIGH_VALUE_DOMAINS.items():
                if any(high_domain in domain for high_domain in domains):
                    self.domain_categories[category].append(domain)
                    
                    # Mark as high risk if it's also an auth cookie
                    if cookie in self.auth_cookies:
                        self.high_risk_cookies.append(cookie)
                    break
            else:
                # If not categorized yet, put in "other"
                self.domain_categories["other"].append(domain)
    
    def assess_privileges(self):
        """Assess potential privileges granted by cookies."""
        results = []
        
        for cookie in self.auth_cookies:
            domain = cookie["domain"].lstrip('.')
            privilege_level = "Unknown"
            risk_level = "Low"
            
            # Determine privilege and risk level
            for category, domains in HIGH_VALUE_DOMAINS.items():
                if any(high_domain in domain for high_domain in domains):
                    if category == "banking":
                        privilege_level = "Financial Account Access"
                        risk_level = "Critical"
                    elif category == "email":
                        privilege_level = "Email Account Access"
                        risk_level = "High"
                    elif category == "social_media":
                        privilege_level = "Social Media Account Access"
                        risk_level = "Medium"
                    elif category == "shopping":
                        privilege_level = "Shopping Account Access"
                        risk_level = "Medium"
                    elif category == "cloud_storage":
                        privilege_level = "Cloud Storage Access"
                        risk_level = "High"
                    break
            
            # Adjust risk based on cookie properties
            if cookie.get("secure", False):
                if risk_level == "Low":
                    risk_level = "Medium"  # Secure flag suggests importance
            
            # Check expiration
            if "expires" in cookie:
                try:
                    expires_date = datetime.datetime.fromtimestamp(cookie["expires"])
                    now = datetime.datetime.now()
                    if expires_date > now + datetime.timedelta(days=30):
                        note = "Long-lived cookie (expires after 30+ days)"
                    else:
                        note = f"Expires on {expires_date.strftime('%Y-%m-%d')}"
                except:
                    note = "Expiration date parsing error"
            else:
                note = "No expiration date (session cookie)"
            
            results.append({
                "domain": domain,
                "cookie_name": cookie["name"],
                "privilege_level": privilege_level,
                "risk_level": risk_level,
                "note": note
            })
        
        return results
    
    def analyze(self, file_path):
        """Perform full analysis on cookie file."""
        # Reset all data structures
        self.cookies = []
        self.domains = set()
        self.auth_cookies = []
        self.domain_categories = defaultdict(list)
        self.high_risk_cookies = []
        self.tracking_cookies = []
        
        if not self.load_cookies(file_path):
            return False
            
        self.identify_auth_cookies()
        self.categorize_domains()
        privilege_assessment = self.assess_privileges()
        
        return {
            "total_cookies": len(self.cookies),
            "unique_domains": len(self.domains),
            "auth_cookies": len(self.auth_cookies),
            "tracking_cookies": len(self.tracking_cookies),
            "high_risk_cookies": len(self.high_risk_cookies),
            "domain_categories": dict(self.domain_categories),
            "privilege_assessment": privilege_assessment,
            "domains": list(self.domains)
        }
    
    def generate_report(self, analysis_results):
        """Generate a human-readable report from analysis results."""
        if not analysis_results:
            return "Analysis failed. Please check the cookie file format."
            
        report = []
        report.append("=" * 80)
        report.append("COOKIE ANALYSIS REPORT")
        report.append("=" * 80)
        report.append("")
        
        report.append(f"Total cookies analyzed: {analysis_results['total_cookies']}")
        report.append(f"Unique domains: {analysis_results['unique_domains']}")
        report.append(f"Authentication cookies: {analysis_results['auth_cookies']}")
        report.append(f"Tracking cookies: {analysis_results['tracking_cookies']}")
        report.append(f"High-risk cookies: {analysis_results['high_risk_cookies']}")
        report.append("")
        
        report.append("DOMAIN CATEGORIES")
        report.append("-" * 80)
        for category, domains in analysis_results['domain_categories'].items():
            unique_domains = set(domains)
            report.append(f"{category.replace('_', ' ').title()}: {len(unique_domains)} domains")
        report.append("")
        
        if analysis_results['privilege_assessment']:
            report.append("POTENTIAL PRIVILEGES")
            report.append("-" * 80)
            for privilege in analysis_results['privilege_assessment']:
                report.append(f"Domain: {privilege['domain']}")
                report.append(f"  Cookie: {privilege['cookie_name']}")
                report.append(f"  Privilege: {privilege['privilege_level']}")
                report.append(f"  Risk Level: {privilege['risk_level']}")
                report.append(f"  Note: {privilege['note']}")
                report.append("")
        
        report.append("HIGH-VALUE DOMAINS")
        report.append("-" * 80)
        high_value_found = False
        for category, domains in analysis_results['domain_categories'].items():
            if category in ["banking", "email", "social_media", "cloud_storage"]:
                unique_domains = set(domains)
                if unique_domains:
                    high_value_found = True
                    report.append(f"{category.replace('_', ' ').title()}:")
                    for domain in sorted(unique_domains):
                        report.append(f"  - {domain}")
        
        if not high_value_found:
            report.append("  No high-value domains found")
        
        report.append("")
        report.append("=" * 80)
        
        return "\n".join(report)

def main():
    parser = argparse.ArgumentParser(description="Analyze browser cookie files for login status and privileges")
    parser.add_argument("cookie_file", help="Path to the cookie file (Netscape format or JSON)")
    parser.add_argument("--json", action="store_true", help="Output results as JSON")
    parser.add_argument("--output", "-o", help="Save report to file")
    
    args = parser.parse_args()
    
    analyzer = CookieAnalyzer()
    results = analyzer.analyze(args.cookie_file)
    
    if args.json:
        output = json.dumps(results, indent=2)
    else:
        output = analyzer.generate_report(results)
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Report saved to {args.output}")
    else:
        print(output)

if __name__ == "__main__":
    main()