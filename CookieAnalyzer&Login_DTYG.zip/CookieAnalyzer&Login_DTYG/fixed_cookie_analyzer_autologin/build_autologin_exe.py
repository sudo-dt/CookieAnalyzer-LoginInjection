#!/usr/bin/env python3
"""
Build script for creating a Windows executable of Cookie Analyzer with Auto-Login
"""

import os
import sys
import shutil
import subprocess

def build_exe():
    print("Building Cookie Analyzer with Auto-Login executable...")
    
    # Make sure PyInstaller is installed
    try:
        import PyInstaller
    except ImportError:
        print("PyInstaller not found. Installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Create icon file if it doesn't exist
    if not os.path.exists("icon.ico"):
        print("Creating default icon...")
        try:
            # Try to create a simple icon using PIL
            from PIL import Image, ImageDraw
            
            img = Image.new('RGB', (256, 256), color=(53, 92, 125))
            d = ImageDraw.Draw(img)
            d.ellipse((50, 50, 206, 206), fill=(255, 255, 255))
            d.ellipse((80, 80, 176, 176), fill=(53, 92, 125))
            
            img.save('icon.png')
            
            # Convert PNG to ICO
            img.save('icon.ico')
            print("Icon created successfully.")
        except Exception as e:
            print(f"Could not create icon: {e}")
            print("Continuing without custom icon...")
    
    # Create build directory if it doesn't exist
    if not os.path.exists("build"):
        os.makedirs("build")
    
    # Create dist directory if it doesn't exist
    if not os.path.exists("dist"):
        os.makedirs("dist")
    
    # Copy the fixed version to the main file
    shutil.copy("fixed_cookie_analyzer_autologin.py", "cookie_analyzer_autologin.py")
    print("Using fixed version of cookie_analyzer_autologin.py")
    
    # Build the executable
    print("Running PyInstaller...")
    
    pyinstaller_args = [
        "pyinstaller",
        "--onefile",  # Create a single executable
        "--windowed",  # Windows application (no console)
        "--name", "CookieAnalyzerAutoLogin",  # Name of the executable
        "--clean",  # Clean PyInstaller cache
        "--distpath", "./dist",  # Output directory
        "--workpath", "./build",  # Working directory
    ]
    
    # Add icon if it exists
    if os.path.exists("icon.ico"):
        pyinstaller_args.extend(["--icon", "icon.ico"])
    
    # Add the main script
    pyinstaller_args.append("cookie_analyzer_autologin.py")
    
    # Run PyInstaller
    subprocess.check_call(pyinstaller_args)
    
    print("\nBuild completed!")
    print(f"Executable created at: {os.path.abspath('dist/CookieAnalyzerAutoLogin.exe')}")
    
    # Create a simple README file in the dist directory
    with open("dist/README_AUTOLOGIN.txt", "w") as f:
        f.write("""Cookie Analyzer with Auto-Login

This tool analyzes browser cookie files to determine login status, domains, and potential privileges.
It also allows you to automatically log into websites using your cookies.

Usage:
1. Run CookieAnalyzerAutoLogin.exe
2. Click "Browse" to select your cookie file
3. Click "Analyze" to analyze the cookies
4. Use the Quick Auto-Login section at the top to select a domain and browser
5. Click "Launch Browser & Login" to attempt automatic login

You can also use the Auto-Login tab for more detailed options.

SECURITY WARNING:
This tool can provide access to your accounts. Only use it with your own cookie files and on your own computer.

For more information, visit: https://github.com/yourusername/cookie-analyzer
""")

if __name__ == "__main__":
    build_exe()