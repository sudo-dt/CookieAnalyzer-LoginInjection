#!/usr/bin/env python3
"""
Cookie Analyzer with Auto-Login Functionality

This enhanced version of Cookie Analyzer allows users to:
1. Analyze browser cookie files
2. Detect login/authentication cookies
3. Automatically inject cookies into a browser to log into websites
"""

import os
import sys
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import webbrowser
import subprocess
import tempfile
import platform
import threading
import time
from urllib.parse import urlparse
from cookie_analyzer import CookieAnalyzer

class BrowserIntegration:
    """Handles browser integration and cookie injection for auto-login"""
    
    def __init__(self):
        self.system = platform.system()
        self.temp_dir = tempfile.mkdtemp(prefix="cookie_analyzer_")
        
    def get_default_browser(self):
        """Detect the default browser on the system"""
        if self.system == "Windows":
            import winreg
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                                    r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as key:
                    browser = winreg.QueryValueEx(key, "ProgId")[0]
                    
                if "chrome" in browser.lower():
                    return "chrome"
                elif "firefox" in browser.lower():
                    return "firefox"
                elif "edge" in browser.lower():
                    return "edge"
                else:
                    return "default"
            except:
                return "default"
        elif self.system == "Darwin":  # macOS
            # On macOS, we'll use the default browser
            return "default"
        else:  # Linux
            # Try to detect common browsers
            browsers = ["google-chrome", "firefox", "chromium-browser"]
            for browser in browsers:
                if self._command_exists(browser):
                    return browser
            return "default"
    
    def _command_exists(self, cmd):
        """Check if a command exists on the system"""
        return subprocess.call(["which", cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE) == 0
    
    def create_cookie_injection_script(self, domain, cookies):
        """Create a JavaScript file to inject cookies"""
        script_content = """
// Cookie Analyzer Auto-Login Script
function setCookie(name, value, domain, path, secure, expires) {
    let cookieStr = encodeURIComponent(name) + "=" + encodeURIComponent(value);
    
    if (domain) {
        cookieStr += "; domain=" + domain;
    }
    
    if (path) {
        cookieStr += "; path=" + path;
    }
    
    if (secure) {
        cookieStr += "; secure";
    }
    
    if (expires) {
        cookieStr += "; expires=" + expires;
    }
    
    document.cookie = cookieStr;
    console.log("Set cookie: " + name);
}

// Cookies to inject
"""
        
        # Add each cookie to the script
        for cookie in cookies:
            expires = "new Date(Date.now() + 86400000).toUTCString()" # 1 day from now
            if "expires" in cookie and cookie["expires"]:
                try:
                    expires = f"new Date({cookie['expires'] * 1000}).toUTCString()"
                except:
                    pass
                    
            script_content += f"""
setCookie(
    "{cookie['name']}", 
    "{cookie['value']}", 
    "{cookie['domain']}", 
    "{cookie.get('path', '/')}", 
    {str(cookie.get('secure', False)).lower()}, 
    {expires}
);
"""
        
        # Add reload to apply cookies
        script_content += """
// Reload the page to apply cookies
console.log("Cookies set, reloading page...");
setTimeout(function() {
    window.location.reload();
}, 1000);
"""
        
        # Save the script to a temporary file
        script_path = os.path.join(self.temp_dir, "inject_cookies.js")
        with open(script_path, "w") as f:
            f.write(script_content)
            
        return script_path
    
    def create_extension_files(self, domain, cookies):
        """Create a temporary Chrome extension for cookie injection"""
        # Create manifest.json
        manifest = {
            "name": "Cookie Analyzer Auto-Login",
            "version": "1.0",
            "description": "Temporary extension to inject cookies for auto-login",
            "permissions": [
                "cookies",
                "tabs",
                "activeTab",
                "scripting",
                f"*://*.{domain}/*",
                f"*://{domain}/*"
            ],
            "host_permissions": [
                f"*://*.{domain}/*",
                f"*://{domain}/*"
            ],
            "background": {
                "service_worker": "background.js"
            },
            "content_scripts": [
                {
                    "matches": [f"*://*.{domain}/*", f"*://{domain}/*"],
                    "js": ["content.js"],
                    "run_at": "document_idle"
                }
            ],
            "manifest_version": 3
        }
        
        # Create background.js
        background_js = """
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
        });
    }
});
"""
        
        # Create content.js to set cookies
        content_js = """
// Cookie Analyzer Auto-Login Script
function setCookie(name, value, domain, path, secure, expires) {
    let cookieStr = encodeURIComponent(name) + "=" + encodeURIComponent(value);
    
    if (domain) {
        cookieStr += "; domain=" + domain;
    }
    
    if (path) {
        cookieStr += "; path=" + path;
    }
    
    if (secure) {
        cookieStr += "; secure";
    }
    
    if (expires) {
        cookieStr += "; expires=" + expires;
    }
    
    document.cookie = cookieStr;
    console.log("Set cookie: " + name);
}

// Cookies to inject
"""
        
        # Add each cookie to the script
        for cookie in cookies:
            expires = "new Date(Date.now() + 86400000).toUTCString()" # 1 day from now
            if "expires" in cookie and cookie["expires"]:
                try:
                    expires = f"new Date({cookie['expires'] * 1000}).toUTCString()"
                except:
                    pass
                    
            content_js += f"""
setCookie(
    "{cookie['name']}", 
    "{cookie['value']}", 
    "{cookie['domain']}", 
    "{cookie.get('path', '/')}", 
    {str(cookie.get('secure', False)).lower()}, 
    {expires}
);
"""
        
        # Create extension directory
        ext_dir = os.path.join(self.temp_dir, "cookie_extension")
        os.makedirs(ext_dir, exist_ok=True)
        
        # Write files
        with open(os.path.join(ext_dir, "manifest.json"), "w") as f:
            json.dump(manifest, f, indent=2)
            
        with open(os.path.join(ext_dir, "background.js"), "w") as f:
            f.write(background_js)
            
        with open(os.path.join(ext_dir, "content.js"), "w") as f:
            f.write(content_js)
            
        return ext_dir
    
    def launch_browser_with_cookies(self, url, domain, cookies, browser_type=None):
        """Launch a browser with the specified cookies injected"""
        if not browser_type:
            browser_type = self.get_default_browser()
            
        # Extract base domain for cookie injection
        parsed_url = urlparse(url)
        base_domain = parsed_url.netloc
        if not base_domain:
            base_domain = domain.lstrip('.')
            url = f"https://{base_domain}"
            
        if browser_type == "chrome" or browser_type == "edge" or browser_type == "chromium-browser":
            # Create extension for Chrome/Edge
            ext_dir = self.create_extension_files(base_domain, cookies)
            
            # Launch Chrome with the extension
            if self.system == "Windows":
                browser_path = self._find_chrome_path() if browser_type == "chrome" else self._find_edge_path()
                if browser_path:
                    cmd = [
                        browser_path,
                        f"--load-extension={ext_dir}",
                        "--no-first-run",
                        f"--user-data-dir={os.path.join(self.temp_dir, 'chrome_profile')}",
                        url
                    ]
                    subprocess.Popen(cmd)
                    return True
            else:
                # For macOS and Linux
                browser_cmd = "google-chrome" if browser_type == "chrome" else "microsoft-edge"
                if self.system == "Darwin":  # macOS
                    browser_cmd = "open -a 'Google Chrome'" if browser_type == "chrome" else "open -a 'Microsoft Edge'"
                    
                cmd = [
                    browser_cmd,
                    f"--load-extension={ext_dir}",
                    "--no-first-run",
                    f"--user-data-dir={os.path.join(self.temp_dir, 'chrome_profile')}",
                    url
                ]
                subprocess.Popen(cmd)
                return True
        
        elif browser_type == "firefox":
            # Firefox requires a different approach - we'll use a temporary profile
            profile_dir = os.path.join(self.temp_dir, "firefox_profile")
            os.makedirs(profile_dir, exist_ok=True)
            
            # Create user.js to disable security features that might block our cookies
            user_js = """
user_pref("security.fileuri.strict_origin_policy", false);
user_pref("privacy.firstparty.isolate", false);
user_pref("network.cookie.cookieBehavior", 0);
user_pref("network.cookie.lifetimePolicy", 0);
"""
            with open(os.path.join(profile_dir, "user.js"), "w") as f:
                f.write(user_js)
                
            # Create a script to inject cookies
            script_path = self.create_cookie_injection_script(base_domain, cookies)
            
            # Launch Firefox with the profile
            if self.system == "Windows":
                firefox_path = self._find_firefox_path()
                if firefox_path:
                    cmd = [
                        firefox_path,
                        "-profile", profile_dir,
                        "-url", url
                    ]
                    subprocess.Popen(cmd)
                    
                    # Wait a bit and then open the developer console to inject cookies
                    time.sleep(3)
                    webbrowser.open(f"javascript:(function(){{var script=document.createElement('script');script.src='{script_path}';document.body.appendChild(script);}})();")
                    return True
            else:
                # For macOS and Linux
                firefox_cmd = "firefox"
                if self.system == "Darwin":  # macOS
                    firefox_cmd = "open -a Firefox"
                    
                cmd = [
                    firefox_cmd,
                    "-profile", profile_dir,
                    "-url", url
                ]
                subprocess.Popen(cmd)
                
                # Wait a bit and then open the developer console to inject cookies
                time.sleep(3)
                webbrowser.open(f"javascript:(function(){{var script=document.createElement('script');script.src='{script_path}';document.body.appendChild(script);}})();")
                return True
        
        else:
            # For other browsers, we'll just use the default browser and try to inject cookies via JavaScript
            script_path = self.create_cookie_injection_script(base_domain, cookies)
            
            # Create an HTML file that will load the script
            html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Cookie Analyzer Auto-Login</title>
    <script src="{script_path}"></script>
    <meta http-equiv="refresh" content="2;url={url}">
</head>
<body>
    <h1>Cookie Analyzer Auto-Login</h1>
    <p>Setting cookies for {base_domain}...</p>
    <p>You will be redirected in 2 seconds.</p>
</body>
</html>
"""
            html_path = os.path.join(self.temp_dir, "inject.html")
            with open(html_path, "w") as f:
                f.write(html_content)
                
            # Open the HTML file in the default browser
            webbrowser.open(f"file://{html_path}")
            return True
            
        return False
    
    def _find_chrome_path(self):
        """Find the Chrome executable path on Windows"""
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe") as key:
                return winreg.QueryValue(key, None)
        except:
            # Try common locations
            common_locations = [
                os.path.join(os.environ.get("PROGRAMFILES", "C:\\Program Files"), "Google\\Chrome\\Application\\chrome.exe"),
                os.path.join(os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)"), "Google\\Chrome\\Application\\chrome.exe"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google\\Chrome\\Application\\chrome.exe")
            ]
            
            for location in common_locations:
                if os.path.exists(location):
                    return location
                    
            return None
    
    def _find_edge_path(self):
        """Find the Edge executable path on Windows"""
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe") as key:
                return winreg.QueryValue(key, None)
        except:
            # Try common locations
            common_locations = [
                os.path.join(os.environ.get("PROGRAMFILES", "C:\\Program Files"), "Microsoft\\Edge\\Application\\msedge.exe"),
                os.path.join(os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)"), "Microsoft\\Edge\\Application\\msedge.exe")
            ]
            
            for location in common_locations:
                if os.path.exists(location):
                    return location
                    
            return None
    
    def _find_firefox_path(self):
        """Find the Firefox executable path on Windows"""
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\firefox.exe") as key:
                return winreg.QueryValue(key, None)
        except:
            # Try common locations
            common_locations = [
                os.path.join(os.environ.get("PROGRAMFILES", "C:\\Program Files"), "Mozilla Firefox\\firefox.exe"),
                os.path.join(os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)"), "Mozilla Firefox\\firefox.exe")
            ]
            
            for location in common_locations:
                if os.path.exists(location):
                    return location
                    
            return None
    
    def cleanup(self):
        """Clean up temporary files"""
        try:
            import shutil
            shutil.rmtree(self.temp_dir, ignore_errors=True)
        except:
            pass

class CookieAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Cookie Analyzer with Auto-Login")
        self.root.geometry("1000x700")
        self.root.minsize(800, 600)
        
        # Set icon if available
        try:
            if getattr(sys, 'frozen', False):
                # Running as compiled exe
                base_dir = sys._MEIPASS
            else:
                # Running as script
                base_dir = os.path.dirname(os.path.abspath(__file__))
                
            icon_path = os.path.join(base_dir, "icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception:
            pass
            
        self.analyzer = CookieAnalyzer()
        self.browser_integration = BrowserIntegration()
        self.analysis_results = None
        self.domain_cookies = {}  # Store domain cookies for auto-login
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        title_label = ttk.Label(title_frame, text="Cookie Analyzer with Auto-Login", font=("Helvetica", 16, "bold"))
        title_label.pack(side=tk.LEFT)
        
        # File selection frame
        file_frame = ttk.LabelFrame(main_frame, text="Select Cookie File", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.file_path_var = tk.StringVar()
        file_path_entry = ttk.Entry(file_frame, textvariable=self.file_path_var, width=50)
        file_path_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        
        browse_button = ttk.Button(file_frame, text="Browse", command=self.browse_file)
        browse_button.pack(side=tk.LEFT, padx=(0, 5))
        
        analyze_button = ttk.Button(file_frame, text="Analyze", command=self.analyze_file)
        analyze_button.pack(side=tk.LEFT)
        
        # Info frame
        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.X, pady=(0, 10))
        
        info_text = "Upload your browser cookie file to analyze login status, domains, and potential privileges. You can also auto-login to websites using your cookies."
        info_label = ttk.Label(info_frame, text=info_text, wraplength=800)
        info_label.pack(fill=tk.X)
        
        # Auto-Login Quick Access Frame - NEW ADDITION
        autologin_frame = ttk.LabelFrame(main_frame, text="Quick Auto-Login", padding="10")
        autologin_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Domain selection
        domain_label = ttk.Label(autologin_frame, text="Domain:")
        domain_label.grid(row=0, column=0, padx=(0, 5), pady=5, sticky="w")
        
        self.domain_var = tk.StringVar()
        self.domain_combo = ttk.Combobox(autologin_frame, textvariable=self.domain_var, width=30, state="readonly")
        self.domain_combo.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        # Browser selection
        browser_label = ttk.Label(autologin_frame, text="Browser:")
        browser_label.grid(row=0, column=2, padx=(20, 5), pady=5, sticky="w")
        
        self.browser_var = tk.StringVar(value="default")
        browsers = [("Default Browser", "default"), ("Google Chrome", "chrome"), 
                   ("Mozilla Firefox", "firefox"), ("Microsoft Edge", "edge")]
        
        self.browser_combo = ttk.Combobox(autologin_frame, textvariable=self.browser_var, width=15, state="readonly")
        self.browser_combo["values"] = [b[0] for b in browsers]
        self.browser_combo.current(0)
        self.browser_combo.grid(row=0, column=3, padx=5, pady=5, sticky="w")
        
        # Login button
        login_button = ttk.Button(
            autologin_frame, 
            text="Launch Browser & Login", 
            command=self.quick_login,
            state="disabled"  # Initially disabled until analysis is done
        )
        login_button.grid(row=0, column=4, padx=(20, 0), pady=5, sticky="e")
        self.login_button = login_button  # Store reference to enable later
        
        # Configure grid
        autologin_frame.columnconfigure(1, weight=1)
        autologin_frame.columnconfigure(3, weight=1)
        
        # Notebook for results
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Summary tab
        self.summary_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.summary_frame, text="Summary")
        
        # Auto-Login tab
        self.login_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.login_frame, text="Auto-Login")
        
        # Privileges tab
        self.privileges_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.privileges_frame, text="Privileges")
        
        # Domains tab
        self.domains_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.domains_frame, text="Domains")
        
        # Report tab
        self.report_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.report_frame, text="Full Report")
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Footer
        footer_frame = ttk.Frame(main_frame)
        footer_frame.pack(fill=tk.X, pady=(10, 0))
        
        footer_text = "Cookie Analyzer © 2025 - Analyze browser cookies and auto-login to websites"
        footer_label = ttk.Label(footer_frame, text=footer_text)
        footer_label.pack(side=tk.LEFT)
        
        # Initial message in summary frame
        initial_msg = "Upload a cookie file and click 'Analyze' to see results."
        initial_label = ttk.Label(self.summary_frame, text=initial_msg, font=("Helvetica", 12))
        initial_label.pack(expand=True)
        
        # Initial message in login frame
        login_msg = "After analyzing cookies, you can use this tab to auto-login to websites."
        login_label = ttk.Label(self.login_frame, text=login_msg, font=("Helvetica", 12))
        login_label.pack(expand=True)
    
    def browse_file(self):
        filetypes = [
            ("Cookie Files", "*.txt;*.json"),
            ("Text Files", "*.txt"),
            ("JSON Files", "*.json"),
            ("All Files", "*.*")
        ]
        
        file_path = filedialog.askopenfilename(
            title="Select Cookie File",
            filetypes=filetypes
        )
        
        if file_path:
            self.file_path_var.set(file_path)
    
    def analyze_file(self):
        file_path = self.file_path_var.get()
        
        if not file_path:
            messagebox.showerror("Error", "Please select a cookie file first.")
            return
            
        if not os.path.exists(file_path):
            messagebox.showerror("Error", "The selected file does not exist.")
            return
            
        # Clear previous results
        for widget in self.summary_frame.winfo_children():
            widget.destroy()
        for widget in self.login_frame.winfo_children():
            widget.destroy()
        for widget in self.privileges_frame.winfo_children():
            widget.destroy()
        for widget in self.domains_frame.winfo_children():
            widget.destroy()
        for widget in self.report_frame.winfo_children():
            widget.destroy()
            
        # Update status
        self.status_var.set("Analyzing cookie file...")
        self.root.update_idletasks()
        
        try:
            # Analyze the file
            results = self.analyzer.analyze(file_path)
            self.analysis_results = results
            
            if not results:
                messagebox.showerror("Error", "Failed to analyze the cookie file. Please check the format.")
                self.status_var.set("Analysis failed")
                return
                
            # Generate report
            report = self.analyzer.generate_report(results)
            
            # Update status
            self.status_var.set(f"Analysis complete - {results['total_cookies']} cookies analyzed")
            
            # Display results
            self.display_summary(results)
            self.display_auto_login(results)
            self.display_privileges(results)
            self.display_domains(results)
            self.display_report(report)
            
            # Update Quick Auto-Login section
            self.update_quick_login_options()
            
            # Switch to summary tab
            self.notebook.select(0)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred during analysis: {str(e)}")
            self.status_var.set("Analysis failed")
    
    def update_quick_login_options(self):
        """Update the quick auto-login dropdown with available domains"""
        # Process domains and add to dropdown
        domain_auth_count = {}
        self.domain_cookies = {}
        
        # Count auth cookies per domain
        for cookie in self.analyzer.auth_cookies:
            domain = cookie["domain"].lstrip('.')
            if domain not in domain_auth_count:
                domain_auth_count[domain] = 0
                self.domain_cookies[domain] = []
                
            domain_auth_count[domain] += 1
            self.domain_cookies[domain].append(cookie)
        
        # Sort domains by auth cookie count (highest first)
        sorted_domains = sorted(domain_auth_count.items(), key=lambda x: x[1], reverse=True)
        
        # Update domain dropdown
        domain_values = []
        for domain, count in sorted_domains:
            if count >= 3:
                chance = "High"
            elif count == 2:
                chance = "Medium"
            else:
                chance = "Low"
            domain_values.append(f"{domain} ({count} cookies, {chance} chance)")
        
        self.domain_combo["values"] = domain_values
        if domain_values:
            self.domain_combo.current(0)
            self.login_button["state"] = "normal"  # Enable login button
    
    def quick_login(self):
        """Handle quick auto-login from the main interface"""
        if not self.domain_cookies:
            messagebox.showerror("Error", "No authentication cookies found. Please analyze a cookie file first.")
            return
        
        # Get selected domain from dropdown
        selected = self.domain_combo.get()
        if not selected:
            messagebox.showerror("Error", "Please select a domain first.")
            return
        
        # Extract domain name from dropdown text (remove the count and chance info)
        domain = selected.split(" (")[0]
        
        # Get cookies for this domain
        if domain not in self.domain_cookies:
            messagebox.showerror("Error", "No authentication cookies found for this domain.")
            return
            
        cookies = self.domain_cookies[domain]
        
        # Get selected browser
        browser_type = self.browser_var.get().lower()
        if browser_type == "default browser":
            browser_type = "default"
        elif browser_type == "google chrome":
            browser_type = "chrome"
        elif browser_type == "mozilla firefox":
            browser_type = "firefox"
        elif browser_type == "microsoft edge":
            browser_type = "edge"
        
        # Confirm with user
        confirm = messagebox.askyesno(
            "Confirm Auto-Login",
            f"This will launch a browser and attempt to log into {domain} using your cookies.\n\n"
            f"Number of authentication cookies: {len(cookies)}\n\n"
            "Do you want to continue?"
        )
        
        if not confirm:
            return
            
        # Update status
        self.status_var.set(f"Launching browser for {domain}...")
        self.root.update_idletasks()
        
        # Construct URL
        url = f"https://{domain}"
        
        # Launch browser in a separate thread to avoid freezing the UI
        threading.Thread(
            target=self.browser_login_thread,
            args=(url, domain, cookies, browser_type),
            daemon=True
        ).start()
    
    def display_summary(self, results):
        # Create a frame for summary stats
        stats_frame = ttk.Frame(self.summary_frame)
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Summary statistics
        stats = [
            ("Total Cookies", results["total_cookies"]),
            ("Unique Domains", results["unique_domains"]),
            ("Auth Cookies", results["auth_cookies"]),
            ("Tracking Cookies", results["tracking_cookies"]),
            ("High Risk Cookies", results["high_risk_cookies"])
        ]
        
        # Create stat boxes
        for i, (label, value) in enumerate(stats):
            frame = ttk.Frame(stats_frame, relief=tk.RAISED, borderwidth=1)
            frame.grid(row=0, column=i, padx=5, pady=5, sticky="nsew")
            
            value_label = ttk.Label(frame, text=str(value), font=("Helvetica", 24, "bold"))
            value_label.pack(pady=(10, 5))
            
            desc_label = ttk.Label(frame, text=label)
            desc_label.pack(pady=(0, 10))
            
        # Configure grid
        for i in range(len(stats)):
            stats_frame.columnconfigure(i, weight=1)
            
        # Domain categories
        categories_frame = ttk.LabelFrame(self.summary_frame, text="Domain Categories")
        categories_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create treeview for categories
        tree = ttk.Treeview(categories_frame, columns=("count"), show="headings")
        tree.heading("count", text="Count")
        tree.column("count", width=100, anchor=tk.CENTER)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(categories_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack tree and scrollbar
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Add categories
        for category, domains in results["domain_categories"].items():
            # Get unique domains
            unique_domains = set(domains)
            category_name = category.replace("_", " ").title()
            tree.insert("", tk.END, values=(category_name, len(unique_domains)))
            
        # Auto-login button
        login_button = ttk.Button(
            self.summary_frame, 
            text="Go to Auto-Login Tab", 
            command=lambda: self.notebook.select(1)
        )
        login_button.pack(pady=10)
    
    def display_auto_login(self, results):
        # Create main frame
        main_frame = ttk.Frame(self.login_frame)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Instructions
        instructions = ttk.LabelFrame(main_frame, text="Auto-Login Instructions")
        instructions.pack(fill=tk.X, pady=(0, 10))
        
        instruction_text = """
1. Select a domain from the list below
2. Choose which browser to use
3. Click "Launch Browser & Login" to open a browser with your cookies injected
4. The browser will automatically log you in if valid authentication cookies are present

Note: This feature works best with recent cookies that haven't expired.
"""
        instruction_label = ttk.Label(instructions, text=instruction_text, wraplength=800, justify=tk.LEFT)
        instruction_label.pack(padx=10, pady=10, fill=tk.X)
        
        # Domain selection
        domain_frame = ttk.LabelFrame(main_frame, text="Select Domain")
        domain_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create search frame
        search_frame = ttk.Frame(domain_frame)
        search_frame.pack(fill=tk.X, pady=(10, 5), padx=10)
        
        search_label = ttk.Label(search_frame, text="Search Domains:")
        search_label.pack(side=tk.LEFT, padx=(0, 5))
        
        search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=search_var)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Create domain list with scrollbar
        list_frame = ttk.Frame(domain_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(5, 10))
        
        # Create columns for domain list
        columns = ("domain", "auth_cookies", "login_chance")
        domain_tree = ttk.Treeview(list_frame, columns=columns, show="headings", selectmode="browse")
        
        # Define headings
        domain_tree.heading("domain", text="Domain")
        domain_tree.heading("auth_cookies", text="Auth Cookies")
        domain_tree.heading("login_chance", text="Login Chance")
        
        # Define columns
        domain_tree.column("domain", width=300)
        domain_tree.column("auth_cookies", width=100, anchor=tk.CENTER)
        domain_tree.column("login_chance", width=100, anchor=tk.CENTER)
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=domain_tree.yview)
        domain_tree.configure(yscrollcommand=y_scrollbar.set)
        
        # Pack tree and scrollbar
        domain_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Process domains and add to tree
        domain_auth_count = {}
        domain_cookies = {}
        
        # Count auth cookies per domain
        for cookie in self.analyzer.auth_cookies:
            domain = cookie["domain"].lstrip('.')
            if domain not in domain_auth_count:
                domain_auth_count[domain] = 0
                domain_cookies[domain] = []
                
            domain_auth_count[domain] += 1
            domain_cookies[domain].append(cookie)
        
        # Add domains to tree
        for domain, count in domain_auth_count.items():
            # Determine login chance
            if count >= 3:
                chance = "High"
                tag = "high"
            elif count == 2:
                chance = "Medium"
                tag = "medium"
            else:
                chance = "Low"
                tag = "low"
                
            domain_tree.insert("", tk.END, values=(domain, count, chance), tags=(tag,))
            
        # Configure tags for login chance
        domain_tree.tag_configure("high", background="#c8e6c9")  # Light green
        domain_tree.tag_configure("medium", background="#fff9c4")  # Light yellow
        domain_tree.tag_configure("low", background="#ffccbc")  # Light red
        
        # Search functionality
        def search_domains(*args):
            query = search_var.get().lower()
            
            for item in domain_tree.get_children():
                domain_tree.delete(item)
                
            for domain, count in domain_auth_count.items():
                if query in domain.lower():
                    # Determine login chance
                    if count >= 3:
                        chance = "High"
                        tag = "high"
                    elif count == 2:
                        chance = "Medium"
                        tag = "medium"
                    else:
                        chance = "Low"
                        tag = "low"
                        
                    domain_tree.insert("", tk.END, values=(domain, count, chance), tags=(tag,))
                    
        search_var.trace("w", search_domains)
        
        # Browser selection
        browser_frame = ttk.LabelFrame(main_frame, text="Browser Selection")
        browser_frame.pack(fill=tk.X, pady=(0, 10))
        
        browser_var = tk.StringVar(value="default")
        
        # Get default browser
        default_browser = self.browser_integration.get_default_browser()
        if default_browser != "default":
            browser_var.set(default_browser)
        
        # Browser options
        browsers = [
            ("Default Browser", "default"),
            ("Google Chrome", "chrome"),
            ("Mozilla Firefox", "firefox"),
            ("Microsoft Edge", "edge")
        ]
        
        browser_option_frame = ttk.Frame(browser_frame)
        browser_option_frame.pack(padx=10, pady=10, fill=tk.X)
        
        for text, value in browsers:
            rb = ttk.Radiobutton(
                browser_option_frame, 
                text=text, 
                value=value, 
                variable=browser_var
            )
            rb.pack(side=tk.LEFT, padx=10)
        
        # Login button
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        login_button = ttk.Button(
            button_frame, 
            text="Launch Browser & Login", 
            command=lambda: self.launch_browser_login(domain_tree, domain_cookies, browser_var.get())
        )
        login_button.pack(side=tk.RIGHT, padx=10)
    
    def launch_browser_login(self, domain_tree, domain_cookies, browser_type):
        # Get selected domain
        selection = domain_tree.selection()
        if not selection:
            messagebox.showerror("Error", "Please select a domain first.")
            return
            
        # Get domain from selection
        domain = domain_tree.item(selection, "values")[0]
        
        # Get cookies for this domain
        if domain not in domain_cookies:
            messagebox.showerror("Error", "No authentication cookies found for this domain.")
            return
            
        cookies = domain_cookies[domain]
        
        # Confirm with user
        confirm = messagebox.askyesno(
            "Confirm Auto-Login",
            f"This will launch a browser and attempt to log into {domain} using your cookies.\n\n"
            f"Number of authentication cookies: {len(cookies)}\n\n"
            "Do you want to continue?"
        )
        
        if not confirm:
            return
            
        # Update status
        self.status_var.set(f"Launching browser for {domain}...")
        self.root.update_idletasks()
        
        # Construct URL
        url = f"https://{domain}"
        
        # Launch browser in a separate thread to avoid freezing the UI
        threading.Thread(
            target=self.browser_login_thread,
            args=(url, domain, cookies, browser_type),
            daemon=True
        ).start()
    
    def browser_login_thread(self, url, domain, cookies, browser_type):
        try:
            success = self.browser_integration.launch_browser_with_cookies(url, domain, cookies, browser_type)
            
            if success:
                self.root.after(0, lambda: self.status_var.set(f"Browser launched for {domain}"))
            else:
                self.root.after(0, lambda: self.status_var.set(f"Failed to launch browser for {domain}"))
                self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to launch browser for {domain}"))
        except Exception as e:
            self.root.after(0, lambda: self.status_var.set(f"Error: {str(e)}"))
            self.root.after(0, lambda: messagebox.showerror("Error", f"An error occurred: {str(e)}"))
    
    def display_privileges(self, results):
        if not results["privilege_assessment"]:
            no_data_label = ttk.Label(
                self.privileges_frame, 
                text="No authentication cookies detected that would grant significant privileges.",
                font=("Helvetica", 12)
            )
            no_data_label.pack(expand=True)
            return
            
        # Create treeview for privileges
        columns = ("domain", "cookie", "privilege", "risk", "note")
        tree = ttk.Treeview(self.privileges_frame, columns=columns, show="headings")
        
        # Define headings
        tree.heading("domain", text="Domain")
        tree.heading("cookie", text="Cookie Name")
        tree.heading("privilege", text="Privilege")
        tree.heading("risk", text="Risk Level")
        tree.heading("note", text="Note")
        
        # Define columns
        tree.column("domain", width=150)
        tree.column("cookie", width=150)
        tree.column("privilege", width=200)
        tree.column("risk", width=100)
        tree.column("note", width=250)
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(self.privileges_frame, orient=tk.VERTICAL, command=tree.yview)
        x_scrollbar = ttk.Scrollbar(self.privileges_frame, orient=tk.HORIZONTAL, command=tree.xview)
        tree.configure(yscrollcommand=y_scrollbar.set, xscrollcommand=x_scrollbar.set)
        
        # Pack tree and scrollbars
        tree.grid(row=0, column=0, sticky="nsew")
        y_scrollbar.grid(row=0, column=1, sticky="ns")
        x_scrollbar.grid(row=1, column=0, sticky="ew")
        
        # Configure grid
        self.privileges_frame.rowconfigure(0, weight=1)
        self.privileges_frame.columnconfigure(0, weight=1)
        
        # Add data
        for privilege in results["privilege_assessment"]:
            tree.insert("", tk.END, values=(
                privilege["domain"],
                privilege["cookie_name"],
                privilege["privilege_level"],
                privilege["risk_level"],
                privilege["note"]
            ))
            
        # Add tags for risk levels
        for item in tree.get_children():
            risk_level = tree.item(item, "values")[3].lower()
            if risk_level == "critical":
                tree.tag_configure("critical", background="#ffcccc")
                tree.item(item, tags=("critical",))
            elif risk_level == "high":
                tree.tag_configure("high", background="#ffe0cc")
                tree.item(item, tags=("high",))
            elif risk_level == "medium":
                tree.tag_configure("medium", background="#ffffcc")
                tree.item(item, tags=("medium",))
    
    def display_domains(self, results):
        # Create notebook for domain categories
        domain_notebook = ttk.Notebook(self.domains_frame)
        domain_notebook.pack(fill=tk.BOTH, expand=True)
        
        # All domains tab
        all_domains_frame = ttk.Frame(domain_notebook, padding="10")
        domain_notebook.add(all_domains_frame, text=f"All Domains ({len(results['domains'])})")
        
        # Create search frame
        search_frame = ttk.Frame(all_domains_frame)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        
        search_label = ttk.Label(search_frame, text="Search:")
        search_label.pack(side=tk.LEFT, padx=(0, 5))
        
        search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=search_var)
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Create listbox with scrollbar
        domains_frame = ttk.Frame(all_domains_frame)
        domains_frame.pack(fill=tk.BOTH, expand=True)
        
        domains_listbox = tk.Listbox(domains_frame, selectmode=tk.SINGLE)
        domains_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(domains_frame, orient=tk.VERTICAL, command=domains_listbox.yview)
        domains_listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Add domains to listbox
        for domain in sorted(results["domains"]):
            domains_listbox.insert(tk.END, domain)
            
        # Search functionality
        def search_domains(*args):
            query = search_var.get().lower()
            domains_listbox.delete(0, tk.END)
            
            for domain in sorted(results["domains"]):
                if query in domain.lower():
                    domains_listbox.insert(tk.END, domain)
                    
        search_var.trace("w", search_domains)
        
        # Add tabs for high-value domains
        high_value_categories = ["banking", "email", "social_media", "cloud_storage"]
        
        for category in high_value_categories:
            if category in results["domain_categories"] and results["domain_categories"][category]:
                unique_domains = set(results["domain_categories"][category])
                
                if unique_domains:
                    category_frame = ttk.Frame(domain_notebook, padding="10")
                    category_name = category.replace("_", " ").title()
                    domain_notebook.add(category_frame, text=f"{category_name} ({len(unique_domains)})")
                    
                    # Create listbox with scrollbar
                    cat_domains_frame = ttk.Frame(category_frame)
                    cat_domains_frame.pack(fill=tk.BOTH, expand=True)
                    
                    cat_domains_listbox = tk.Listbox(cat_domains_frame, selectmode=tk.SINGLE)
                    cat_domains_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                    
                    cat_scrollbar = ttk.Scrollbar(cat_domains_frame, orient=tk.VERTICAL, command=cat_domains_listbox.yview)
                    cat_domains_listbox.configure(yscrollcommand=cat_scrollbar.set)
                    cat_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                    
                    # Add domains to listbox
                    for domain in sorted(unique_domains):
                        cat_domains_listbox.insert(tk.END, domain)
        
        # Add tracking domains tab
        if "tracking" in results["domain_categories"] and results["domain_categories"]["tracking"]:
            unique_tracking = set(results["domain_categories"]["tracking"])
            
            if unique_tracking:
                tracking_frame = ttk.Frame(domain_notebook, padding="10")
                domain_notebook.add(tracking_frame, text=f"Tracking ({len(unique_tracking)})")
                
                # Create listbox with scrollbar
                track_domains_frame = ttk.Frame(tracking_frame)
                track_domains_frame.pack(fill=tk.BOTH, expand=True)
                
                track_domains_listbox = tk.Listbox(track_domains_frame, selectmode=tk.SINGLE)
                track_domains_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                
                track_scrollbar = ttk.Scrollbar(track_domains_frame, orient=tk.VERTICAL, command=track_domains_listbox.yview)
                track_domains_listbox.configure(yscrollcommand=track_scrollbar.set)
                track_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
                
                # Add domains to listbox
                for domain in sorted(unique_tracking):
                    track_domains_listbox.insert(tk.END, domain)
    
    def display_report(self, report):
        # Create text widget with scrollbar
        report_text = scrolledtext.ScrolledText(self.report_frame, wrap=tk.WORD)
        report_text.pack(fill=tk.BOTH, expand=True)
        
        # Insert report
        report_text.insert(tk.END, report)
        
        # Make read-only
        report_text.configure(state="disabled")
        
        # Add save button
        save_frame = ttk.Frame(self.report_frame)
        save_frame.pack(fill=tk.X, pady=(10, 0))
        
        save_button = ttk.Button(
            save_frame, 
            text="Save Report", 
            command=lambda: self.save_report(report)
        )
        save_button.pack(side=tk.RIGHT)
    
    def save_report(self, report):
        file_path = filedialog.asksaveasfilename(
            title="Save Report",
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(report)
                messagebox.showinfo("Success", f"Report saved to {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save report: {str(e)}")

def main():
    root = tk.Tk()
    app = CookieAnalyzerGUI(root)
    root.mainloop()
    
    # Clean up temporary files
    app.browser_integration.cleanup()

if __name__ == "__main__":
    main()